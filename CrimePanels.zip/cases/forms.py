from django import forms
from .models import Case
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Submit

class CaseForm(forms.ModelForm):
    class Meta:
        model = Case
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(CaseForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_method = 'post'
        self.helper.add_input(Submit('submit', 'Save'))
