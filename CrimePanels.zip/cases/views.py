from django.shortcuts import render, get_object_or_404, redirect
from .models import Case
from .forms import CaseForm
from django.contrib import messages
import json

def case_list(request):
    cases = Case.objects.all()
    return render(request, 'cases/case_list.html', {'cases': cases})

def case_detail(request, pk):
    case = get_object_or_404(Case, pk=pk)

    # Extract Shorts video ID if available
    youtube_id = ""
    if "shorts/" in case.youtube_url:
        youtube_id = case.youtube_url.split("shorts/")[-1].split("?")[0]

    case.description = case.description.replace("\\n", "\n")  # optional for newline fix
    return render(request, 'cases/case_detail.html', {
        'case': case,
        'youtube_id': youtube_id
    })

def case_create(request):
    form = CaseForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('case_list')
    return render(request, 'cases/case_form.html', {'form': form})

def case_update(request, pk):
    case = get_object_or_404(Case, pk=pk)
    form = CaseForm(request.POST or None, instance=case)
    if form.is_valid():
        form.save()
        return redirect('case_list')
    return render(request, 'cases/case_form.html', {'form': form})

def case_delete(request, pk):
    case = get_object_or_404(Case, pk=pk)
    if request.method == 'POST':
        case.delete()
        return redirect('case_list')
    return render(request, 'cases/case_confirm_delete.html', {'case': case})

def case_import_json(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.POST['json_data'])

            for item in data:
                Case.objects.create(
                    title=item['title'],
                    script=item['script'],
                    prompts=item['prompts'],  # if using JSONField
                    description=item['description'],
                    tags=item['tags'],
                    youtube_url=item.get('youtube_url', '')
                )
            messages.success(request, "Cases imported successfully.")
        except Exception as e:
            messages.error(request, f"Error importing JSON: {e}")
    return redirect('case_list')
