from django.db import models

class Case(models.Model):
    title = models.CharField(max_length=255)
    script = models.TextField()
    prompts = models.JSONField()
    description = models.TextField(null=True, blank=True)
    tags = models.TextField(null=True, blank=True)
    youtube_url = models.URLField(null=True, blank=True)

    def __str__(self):
        return self.title
